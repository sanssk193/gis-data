Shape Viewer 1.20
---------------------------------------------------

*What is Shape Viewer?
	Shape Viewer is a free tool, which you can use to view ESRI� Shape files. 
	Shape viewer can open (.shp) files that contain the geometry information of the shape file. 
	With Shape Viewer you can also create a new (.shx) file and a new empty (.dbf) file for your shape file. 

*Why Shape Viewer? 
	If you have tens of shape files to browse quickly and you don't want to use heavy and expensive software such as ArcGIS or Map Info, then Shape Viewer will be your choice. 
	Shape Viewer is a free and light viewer, which can be used to browse and view shape files easily and quickly. 
	If your (.dbf or .shx) files are missing or corrupted, Shape Viewer can generate new ones, so that you will not lose your spatial data. 
	You can associate (.shp) file type with Shape Viewer, so that you can open any (.shp) file in Shape Viewer by double-click the file in Windows Explorer. 

*Requirements: 
	Shape Viewer was created by Microsoft Visual Basic 6.0 (service pack 5.0).
	It requires Microsoft Windows 95 or later. 
	Shape Viewer doesn't use any third-party component to read the shape file contents; it reads the native structure of shape file. 

*Versions history:
	Version 1.20 (July 2005): 
		.Exporting coordinates to MS Excel format. 
		.Fixing a bug in creating the shx file. 
		.Popup menu contains map navigation commands.

	Version 1.10 (April 2005): 
		.new map navigation toolbar. 
		.application Window can be resized. 
		.Polygons in the map is filled with color. 

	Version 1.01 (October 2004). 

*Source code: 
	Source code of Shape viewer is available for sale. For more information please send an e-mail to: mohamed.hammod@gmail.com 

Website: http://www.shapeviewer.com
Email:    mohamed.hammod@gmail.com
